<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ujian extends MY_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('ujian_model');

        must_login();
    }

    private function formatData($val)
    {
        # cari pembuatnya
        if (!empty($val['pengajar_id'])) {
            $pengajar = $this->pengajar_model->retrieve($val['pengajar_id']);
            $val['pembuat'] = $pengajar;
            if (is_admin()) {
                $val['pembuat']['link_profil'] = site_url('pengajar/detail/'.$pengajar['status_id'].'/'.$pengajar['id']);
            } else {
                $val['pembuat']['link_profil'] = site_url('pengajar/detail/'.$pengajar['id']);
            }
        }

        # cari ujian kelas
        $ujian_kelas = $this->ujian_model->retrieve_all_kelas($val['id']);
        foreach ($ujian_kelas as $mk) {
            $kelas = $this->kelas_model->retrieve($mk['kelas_id']);
            $val['ujian_kelas'][] = $kelas;
        }

        # cari matapelajarannya
        $val['mapel'] = $this->mapel_model->retrieve($val['mapel_id']);

        # type label
        if ($val['type_id'] == 1) {
            $val['type_label'] = 'Upload';
        }
        if ($val['type_id'] == 2) {
            $val['type_label'] = 'Essay';
        }
        if ($val['type_id'] == 3) {
            $val['type_label'] = 'Ganda';
        }

        return $val;
    }

    function index($segment_3 = '')
    {
        if (!empty($_GET['clear_filter']) AND $_GET['clear_filter'] == 'true') {
            $this->session->set_userdata('filter_ujian', null);
        }

        $page_no = (int)$segment_3;
        if (empty($page_no)) {
            $page_no = 1;
        }

        # jika ada post filter
        if ($this->form_validation->run('ujian/filter') == true) {
            $pembuat = $this->input->post('pembuat', TRUE);

            # cari id pengajar
            $pengajar_id = array();
            if (!empty($pembuat)) {
                foreach ($this->pengajar_model->retrieve_all_by_name($pembuat) as $val) {
                    $pengajar_id[] = $val['id'];
                }

                if (empty($pengajar_id)) {
                    $pengajar_id[] = 0;
                }
            }

            $filter = array(
                'judul'       => $this->input->post('judul', true),
                'info'        => $this->input->post('info', true),
                'pengajar_id' => $pengajar_id,
                'pembuat'     => $pembuat,
                'mapel_id'    => $this->input->post('mapel_id', true),
                'kelas_id'    => $this->input->post('kelas_id', true),
                'type'        => $this->input->post('type', true),
                'status'      => $this->input->post('status', true),
            );

            $this->session->set_userdata('filter_ujian', $filter);
        }

        $filter = $this->session->userdata('filter_ujian');
        if (empty($filter)) {
            $filter = array(
                'judul'       => '',
                'info'        => '',
                'pengajar_id' => array(),
                'pembuat'     => '',
                'mapel_id'    => array(),
                'kelas_id'    => array(),
                'type'        => array(),
                'status'      => array()
            );
        }

        # jika pengajar, tampilkan ujian yang dia buat
        if (is_pengajar()) {
            $filter['pengajar_id'] = array(get_sess_data('user', 'id'));
        }

        # jika siswa, tampilkan ujian pada kelas aktifnya
        elseif (is_siswa()) {
            $kelas_aktif = $this->siswa_kelas_aktif;
            $filter['kelas_id'] = array($kelas_aktif['kelas_id']);
        }

        if (!empty($_GET['judul'])) {
            $filter['judul'] = (string)$_GET['judul'];
        }

        $data['filter'] = $filter;

        # ambil semua data ujian
        $retrieve_all_ujian = $this->ujian_model->retrieve_all(
            20,
            $page_no,
            $filter['mapel_id'],
            $filter['pengajar_id'],
            $filter['type'],
            $filter['kelas_id'],
            $filter['judul'],
            $filter['info'],
            $filter['status']
        );

        # format array data
        $results = array();
        foreach ($retrieve_all_ujian['results'] as $key => $val) {
            $results[$key] = $this->formatData($val);
        }

        $data['ujian']      = $results;
        $data['pagination'] = $this->pager->view($retrieve_all_ujian, 'ujian/index/');
        $data['kelas']      = $this->kelas_model->retrieve_all_child();
        $data['mapel']      = $this->mapel_model->retrieve_all_mapel();

        # panggil colorbox
        $html_js = load_comp_js(array(
            base_url('assets/comp/colorbox/jquery.colorbox-min.js'),
        ));
        $data['comp_js']  = $html_js;
        $data['comp_css'] = load_comp_css(array(base_url('assets/comp/colorbox/colorbox.css')));

        $this->twig->display('list-ujian.html', $data);
    }

    function add($segment_3 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            $this->session->set_flashdata('ujian', get_alert('warning', 'Akses ditolak.'));
            redirect('ujian');
        }

        $type = (string)strtolower($segment_3);
        if (!in_array($type, array(1, 2, 3))) {
            redirect('ujian');
        }

        # type label
        if ($type == 1) {
            $data['type_label'] = 'Upload';
            $form_validation    = 'ujian/add_upload';
        }
        if ($type == 2) {
            $data['type_label'] = 'Essay';
            $form_validation    = 'ujian/add_ganda_essay';
        }
        if ($type == 3) {
            $data['type_label'] = 'Ganda';
            $form_validation    = 'ujian/add_ganda_essay';
        }

        $data['type']    = $type;
        $data['mapel']   = $this->mapel_model->retrieve_all_mapel();
        $data['kelas']   = $this->kelas_model->retrieve_all_child();
        $data['comp_js'] = get_texteditor();
        $this->form_validation->set_rules('mapel_id', 'Mata Pelajaran', 'required');

        if ($this->form_validation->run() == TRUE) {
            $mapel_id = $this->input->post('mapel_id', TRUE);
            $judul    = $this->input->post('judul', TRUE);
            $info     = $this->input->post('info');
            $durasi   = null;
            if ($type != 1) {
                $durasi = $this->input->post('durasi', TRUE);
            }

            $ujian_id = $this->ujian_model->create(
                $mapel_id,
                get_sess_data('user', 'id'),
                $type,
                $judul,
                $durasi,
                $info
            );

            # simpan kelas ujian
            $kelas_id = $this->input->post('kelas_id', TRUE);
            foreach ($kelas_id as $ujian_kelas_id) {
                $this->ujian_model->create_kelas($ujian_id, $ujian_kelas_id);
            }

            if ($type != 1) {
                # redirect ke manajemen soal
                $this->session->set_flashdata('ujian', get_alert('success', 'Manajemen soal ujian.'));
                redirect('ujian/manajemen_soal/' . $ujian_id);
            } else {
                $this->session->set_flashdata('ujian', get_alert('success', 'ujian Upload berhasil disimpan.'));
                redirect('ujian');
            }
        }

        $this->twig->display('tambah-ujian.html', $data);
    }

    function edit($segment_3 = '', $segment_4 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            $this->session->set_flashdata('ujian', get_alert('warning', 'Akses ditolak.'));
            redirect('ujian');
        }

        $ujian_id = (int)$segment_3;
        $uri_back = (string)$segment_4;

        if (empty($uri_back)) {
            $uri_back = site_url('ujian');
        } else {
            $uri_back = deurl_redirect($uri_back);
        }

        $data['uri_back'] = $uri_back;

        if (empty($ujian_id)) {
            redirect($uri_back);
        }

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian)) {
            redirect($uri_back);
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            redirect('ujian');
        }

        # type label
        if ($ujian['type_id'] == 1) {
            $data['type_label'] = 'Upload';
            $form_validation    = 'ujian/add_upload';
        }
        if ($ujian['type_id'] == 2) {
            $data['type_label'] = 'Essay';
            $form_validation    = 'ujian/add_ganda_essay';
        }
        if ($ujian['type_id'] == 3) {
            $data['type_label'] = 'Ganda';
            $form_validation    = 'ujian/add_ganda_essay';
        }

        # hanya ambil kelas_idnya
        $ujian_kelas    = $this->ujian_model->retrieve_all_kelas($ujian['id']);
        $ujian_kelas_id = array();
        foreach ($ujian_kelas as $r) {
            $ujian_kelas_id[] = $r['kelas_id'];
        }

        $data['ujian']       = $ujian;
        $data['ujian_kelas'] = $ujian_kelas_id;
        $data['mapel']       = $this->mapel_model->retrieve_all_mapel();
        $data['kelas']       = $this->kelas_model->retrieve_all_child();
        $data['comp_js']     = get_texteditor();

        if ($this->form_validation->run($form_validation) == TRUE) {
            $mapel_id = $this->input->post('mapel_id', TRUE);
            $judul    = $this->input->post('judul', TRUE);
            $info     = $this->input->post('info');
            $durasi   = null;
            if ($ujian['type_id'] != 1) {
                $durasi = $this->input->post('durasi', TRUE);
            }

            $this->ujian_model->update(
                $ujian['id'],
                $mapel_id,
                $ujian['pengajar_id'],
                $ujian['type_id'],
                $judul,
                $durasi,
                $info,
                $ujian['aktif']
            );

            # cari kelas ujian mana yang harus ditambah / dihapus
            $kelas_id      = $this->input->post('kelas_id', TRUE);
            $kelas_post_id = array();
            foreach ($kelas_id as $post_kelas_id) {
                $post_kelas_id = (int)$post_kelas_id;
                if (!empty($post_kelas_id)) {
                    $check = $this->ujian_model->retrieve_kelas(null, $ujian['id'], $post_kelas_id);
                    if (empty($check)) {
                        # tambahkan
                        $this->ujian_model->create_kelas($ujian['id'], $post_kelas_id);
                    }
                    $kelas_post_id[] = $post_kelas_id;
                }
            }

            if (count($ujian_kelas_id) > count($kelas_post_id)) {
                $diff_kelas = array_diff($ujian_kelas_id, $kelas_post_id);
                foreach ($diff_kelas as $diff_kelas_id) {
                    $retrieve = $this->ujian_model->retrieve_kelas(null, $ujian['id'], $diff_kelas_id);
                    # hapus
                    if (!empty($retrieve)) {
                        $this->ujian_model->delete_kelas($retrieve['id']);
                    }
                }
            }

            $this->session->set_flashdata('ujian', get_alert('success', 'ujian berhasil diperbaharui.'));
            redirect($uri_back);
        }

        $this->twig->display('edit-ujian.html', $data);
    }

    function terbitkan($segment_3 = '', $segment_4 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            $this->session->set_flashdata('ujian', get_alert('warning', 'Akses ditolak.'));
            redirect('ujian');
        }

        $ujian_id = (int)$segment_3;
        $uri_back = (string)$segment_4;

        if (empty($uri_back)) {
            $uri_back = site_url('ujian');
        } else {
            $uri_back = deurl_redirect($uri_back);
        }

        if (empty($ujian_id)) {
            redirect($uri_back);
        }

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian)) {
            redirect($uri_back);
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            redirect('ujian');
        }

        # cek pertanyaan, sudah ada belum
        if ($ujian['type_id'] != 1) {
            $check_pertanyaan = $this->ujian_model->retrieve_all_pertanyaan('all', 1, $ujian['id']);
            if (empty($check_pertanyaan)) {
                $this->session->set_flashdata('ujian', get_alert('warning', 'Pertanyaan masih kosong.'));
                redirect($uri_back);
            }

            # jika pilihan ganda cek pilihannya sudah ada belum
            if ($ujian['type_id'] == 3) {
                $empty_pilihan = array();
                $empty_kunci   = array();
                foreach ($check_pertanyaan as $p) {
                    $pilihan = $this->ujian_model->retrieve_all_pilihan($p['id']);
                    if (empty($pilihan)) {
                        $empty_pilihan[] = $p['urutan'];
                    } else {
                        $ada_kunci = false;
                        # cek kuncinya sudah diatur belum
                        foreach ($pilihan as $pil) {
                            if ($pil['kunci'] == 1) {
                                $ada_kunci = true;
                            }
                        }

                        if (!$ada_kunci) {
                            $empty_kunci[] = $p['urutan'];
                        }
                    }
                }

                if (!empty($empty_pilihan)) {
                    $this->session->set_flashdata('ujian', get_alert('warning', 'Pertanyaan no ' . implode(', ', $empty_pilihan) . ' belum ada pilihan jawaban.'));
                    redirect($uri_back);
                } elseif (!empty($empty_kunci)) {
                    $this->session->set_flashdata('ujian', get_alert('warning', 'Pilihan pertanyaan no ' . implode(', ', $empty_kunci) . ' belum ada kunci jawaban.'));
                    redirect($uri_back);
                }
            }
        }

        # terbitkan ujian
        $this->ujian_model->terbitkan($ujian['id']);

        $this->session->set_flashdata('ujian', get_alert('success', 'ujian berhasil diterbitkan.'));
        redirect($uri_back);
    }

    function tutup($segment_3 = '', $segment_4 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            $this->session->set_flashdata('ujian', get_alert('warning', 'Akses ditolak.'));
            redirect('ujian');
        }

        $ujian_id = (int)$segment_3;
        $uri_back = (string)$segment_4;

        if (empty($uri_back)) {
            $uri_back = site_url('ujian');
        } else {
            $uri_back = deurl_redirect($uri_back);
        }

        if (empty($ujian_id)) {
            redirect($uri_back);
        }

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian)) {
            redirect($uri_back);
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            redirect('ujian');
        }

        # tutup ujian
        $this->ujian_model->tutup($ujian['id']);

        $this->session->set_flashdata('ujian', get_alert('success', 'ujian berhasil ditutup.'));
        redirect($uri_back);
    }

    function manajemen_soal($segment_3 = '', $segment_4 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            $this->session->set_flashdata('ujian', get_alert('warning', 'Akses ditolak.'));
            redirect('ujian');
        }

        $ujian_id = (int)$segment_3;
        $page_no  = (int)$segment_4;
        if (empty($page_no)) {
            $page_no = 1;
        }

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] == 1) {
            redirect('ujian/index');
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            redirect('ujian');
        }

        $data['ujian'] = $this->formatData($ujian);

        # panggil colorbox
        $html_js = load_comp_js(array(
            base_url('assets/comp/colorbox/jquery.colorbox-min.js'),
        ));
        $data['comp_js']  = $html_js;
        $data['comp_css'] = load_comp_css(array(base_url('assets/comp/colorbox/colorbox.css')));

        $retrieve_all = $this->ujian_model->retrieve_all_pertanyaan(
            20,
            $page_no,
            $ujian['id'],
            'DESC'
        );

        # jika pilihan ganda
        if ($ujian['type_id'] == 3) {
            foreach ($retrieve_all['results'] as $key => $val) {
                $val['pilihan'] = $this->ujian_model->retrieve_all_pilihan($val['id']);
                $retrieve_all['results'][$key] = $val;
            }
        }

        $data['pertanyaan'] = $retrieve_all['results'];
        $data['pagination'] = $this->pager->view($retrieve_all, 'ujian/manajemen_soal/' . $ujian['id'] . '/');

        $this->twig->display('manajemen-ujian.html', $data);
    }

    function copy_soal($segment_3 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            exit("Akses ditolak.");
        }

        $ujian_id = (int)$segment_3;

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] == 1) {
            exit("ujian tidak ditemukan");
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            exit("ujian tidak ditemukan");
        }

        # aksi untuk copy pertanyaan
        if (!empty($_GET['copy'])) {
            $pertanyaan_id = (int)$_GET['copy'];
            $pertanyaan    = $this->ujian_model->retrieve_pertanyaan($pertanyaan_id);
            if (empty($pertanyaan)) {
                $this->session->set_flashdata('copy', get_alert('warning', 'Pertanyaan tidak ditemukan.'));
                redirect('ujian/copy_soal/' . $ujian['id']);
            }

            $new_pertanyaan_id = $this->ujian_model->create_pertanyaan($pertanyaan['pertanyaan'], $ujian['id']);

            # cari pilihan
            $pilihan = $this->ujian_model->retrieve_all_pilihan($pertanyaan['id']);
            foreach ($pilihan as $p) {
                $this->ujian_model->create_pilihan(
                    $new_pertanyaan_id,
                    $p['konten'],
                    $p['kunci'],
                    $p['urutan']
                );
            }

            $this->session->set_flashdata('copy', get_alert('success', "Pertanyaan ID $pertanyaan_id berhasil dicopy."));
            redirect('ujian/copy_soal/' . $ujian['id']);
        }

        $data['ujian'] = $ujian;

        # variabel untuk nyimpen biar tidak boros query
        $arr_ujian_id    = array();
        $arr_pengajar_id = array();

        # ambil semua pertanyaan
        $retrieve_all_pertanyaan = $this->ujian_model->retrieve_all_pertanyaan('all', 1, null);
        foreach ($retrieve_all_pertanyaan as $key => $val) {
            # dapatkan informasi pembuat pertanyaan dan pada ujian apa
            if (!isset($arr_ujian_id[$val['ujian_id']])) {
                $info_ujian = $this->ujian_model->retrieve($val['ujian_id']);
                $arr_ujian_id[$val['ujian_id']] = $this->ujian_model->retrieve($val['ujian_id']);
            } else {
                $info_ujian = $arr_ujian_id[$val['ujian_id']];
            }

            //Jika sebagai pengajar, tampilkan yang dia buat saja
            if (is_pengajar() AND $info_ujian['pengajar_id'] != get_sess_data('user', 'id')) {
                unset($retrieve_all_pertanyaan[$key]);
            }

            if (!isset($arr_pengajar_id[$info_ujian['pengajar_id']])) {
                $info_pembuat = $this->pengajar_model->retrieve($info_ujian['pengajar_id']);
            } else {
                $info_pembuat = $arr_pengajar_id[$info_ujian['pengajar_id']];
            }

            if (is_admin()) {
                $info_pembuat['link_profil'] = site_url('pengajar/detail/'.$info_pembuat['status_id'].'/'.$info_pembuat['id']);
            } else {
                $info_pembuat['link_profil'] = site_url('pengajar/detail/'.$info_pembuat['id']);
            }

            $val['info_ujian']   = $info_ujian;
            $val['info_pembuat'] = $info_pembuat;

            # cari pilihan
            $pilihan = $this->ujian_model->retrieve_all_pilihan($val['id']);
            if (!empty($pilihan)) {
                $val['pilihan'] = $pilihan;
            }

            $retrieve_all_pertanyaan[$key] = $val;
        }

        $data['pertanyaan'] = $retrieve_all_pertanyaan;

        # panggil datatables
        $data['comp_js'] = load_comp_js(array(
            base_url('assets/comp/datatables/jquery.dataTables.js'),
            base_url('assets/comp/datatables/datatable-bootstrap2.js'),
        ));

        $data['comp_css'] = load_comp_css(array(
            base_url('assets/comp/datatables/datatable-bootstrap2.css'),
        ));

        $this->twig->display('copy-pertanyaan-ujian.html', $data);
    }

    function tambah_soal($segment_3 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            exit("Akses ditolak.");
        }

        $ujian_id = (int)$segment_3;

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] == 1) {
            exit("ujian tidak ditemukan");
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            exit("ujian tidak ditemukan");
        }

        $data['ujian']         = $ujian;
        $data['comp_js']       = get_texteditor();
        $data['no_pertanyaan'] = $this->ujian_model->count_pertanyaan($ujian['id']) + 1;
        $this->form_validation->set_rules('pertanyaan', 'Pertanyaan', 'required');

        if ($this->form_validation->run() == TRUE) {
            $pertanyaan = $this->input->post('pertanyaan');

            $pertanyaan_id = $this->ujian_model->create_pertanyaan(
                $pertanyaan,
                $ujian['id'],
                $data['no_pertanyaan']
            );

            $this->session->set_flashdata('ujian', get_alert('success', 'Pertanyaan berhasil disimpan.'));
            redirect('ujian/edit_soal/' . $ujian['id'] . '/' . $pertanyaan_id);
        }

        $this->twig->display('tambah-pertanyaan-ujian.html', $data);
    }

    function edit_soal($segment_3 = '', $segment_4 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            exit("Akses ditolak.");
        }

        $ujian_id      = (int)$segment_3;
        $pertanyaan_id = (int)$segment_4;

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] == 1) {
            exit("ujian tidak ditemukan");
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            exit("ujian tidak ditemukan");
        }

        $pertanyaan = $this->ujian_model->retrieve_pertanyaan($pertanyaan_id);
        if (empty($pertanyaan)) {
            exit("Pertanyaan tidak ditemukan");
        }

        $data['pertanyaan']    = $pertanyaan;
        $data['ujian']         = $ujian;
        $data['comp_js']       = get_texteditor();
        $data['no_pertanyaan'] = $pertanyaan['urutan'];
        $this->form_validation->set_rules('pertanyaan', 'Pertanyaan', 'required');

        if ($this->form_validation->run('ujian/pertanyaan') == TRUE) {
            $post_pertanyaan = $this->input->post('pertanyaan');

            $this->ujian_model->update_pertanyaan(
                $pertanyaan['id'],
                $post_pertanyaan,
                $pertanyaan['urutan'],
                $ujian['id']
            );

            $this->session->set_flashdata('ujian', get_alert('success', 'Pertanyaan berhasil diperbaharui.'));
            redirect('ujian/edit_soal/' . $ujian['id'] . '/' . $pertanyaan['id']);
        }

        $this->twig->display('edit-pertanyaan-ujian.html', $data);
    }

    function hapus_soal($segment_3 = '', $segment_4 = '', $segment_5 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            exit("Akses ditolak.");
        }

        $ujian_id      = (int)$segment_3;
        $pertanyaan_id = (int)$segment_4;
        $uri_back      = (string)$segment_5;

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] == 1) {
            exit("ujian tidak ditemukan");
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            exit("ujian tidak ditemukan");
        }

        $pertanyaan = $this->ujian_model->retrieve_pertanyaan($pertanyaan_id);
        if (empty($pertanyaan)) {
            exit("Pertanyaan tidak ditemukan");
        }

        if (empty($uri_back)) {
            $uri_back = site_url('ujian/manajemen_soal/' . $ujian['id']);
        } else {
            $uri_back = deurl_redirect($uri_back);
        }

        # hapus pertanyaan
        $this->ujian_model->delete_pertanyaan($pertanyaan['id']);

        $this->session->set_flashdata('ujian', get_alert('warning', 'Pertanyaan berhasil dihapus.'));
        redirect($uri_back);
    }

    function tambah_pilihan($segment_3 = '', $segment_4 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            exit("Akses ditolak.");
        }

        $ujian_id      = (int)$segment_3;
        $pertanyaan_id = (int)$segment_4;

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] != 3) {
            exit("ujian tidak ditemukan");
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            exit("ujian tidak ditemukan");
        }

        $pertanyaan = $this->ujian_model->retrieve_pertanyaan($pertanyaan_id);
        if (empty($pertanyaan)) {
            exit("Pertanyaan tidak ditemukan");
        }

        $data['pertanyaan']    = $pertanyaan;
        $data['ujian']         = $ujian;
        $data['comp_js']       = get_texteditor();
        $this->form_validation->set_rules('pilihan', 'Pilihan', 'required');

        if ($this->form_validation->run() == TRUE) {
            $post_pilihan = $this->input->post('pilihan', true);
            $post_konten  = $this->input->post('konten');

            $pilihan_id = $this->ujian_model->create_pilihan(
                $pertanyaan['id'],
                $post_konten,
                0,
                $post_pilihan
            );

            $this->session->set_flashdata('ujian', get_alert('success', 'Pilihan berhasil disimpan.'));
            redirect('ujian/edit_pilihan/' . $ujian['id'] . '/' . $pertanyaan['id'] . '/' . $pilihan_id);
        }

        $this->twig->display('tambah-pilihan-ujian.html', $data);
    }

    function edit_pilihan($segment_3 = '', $segment_4 = '', $segment_5 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            exit("Akses ditolak.");
        }

        $ujian_id      = (int)$segment_3;
        $pertanyaan_id = (int)$segment_4;
        $pilihan_id    = (int)$segment_5;

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] != 3) {
            exit("ujian tidak ditemukan");
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            exit("ujian tidak ditemukan");
        }

        $pertanyaan = $this->ujian_model->retrieve_pertanyaan($pertanyaan_id);
        if (empty($pertanyaan)) {
            exit("Pertanyaan tidak ditemukan");
        }

        $pilihan = $this->ujian_model->retrieve_pilihan($pilihan_id, $pertanyaan['id']);
        if (empty($pilihan)) {
            exit("Pilihan tidak ditemukan");
        }

        $data['pilihan']    = $pilihan;
        $data['pertanyaan'] = $pertanyaan;
        $data['ujian']      = $ujian;
        $data['comp_js']    = get_texteditor();
        $this->form_validation->set_rules('pilihan', 'Pilihan', 'required');

        if ($this->form_validation->run() == TRUE) {
            $post_pilihan = $this->input->post('pilihan', true);
            $post_konten  = $this->input->post('konten');

            $this->ujian_model->update_pilihan(
                $pilihan['id'],
                $pertanyaan['id'],
                $post_konten,
                $pilihan['kunci'],
                $post_pilihan
            );

            $this->session->set_flashdata('ujian', get_alert('success', 'Pilihan berhasil diperbaharui.'));
            redirect('ujian/edit_pilihan/' . $ujian['id'] . '/' . $pertanyaan['id'] . '/' . $pilihan_id);
        }

        $this->twig->display('edit-pilihan-ujian.html', $data);
    }

    function kunci_pilihan($segment_3 = '', $segment_4 = '', $segment_5 = '', $segment_6 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            exit("Akses ditolak.");
        }

        $ujian_id      = (int)$segment_3;
        $pertanyaan_id = (int)$segment_4;
        $pilihan_id    = (int)$segment_5;
        $uri_back      = (string)$segment_6;

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] != 3) {
            exit("ujian tidak ditemukan");
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            exit("ujian tidak ditemukan");
        }

        $pertanyaan = $this->ujian_model->retrieve_pertanyaan($pertanyaan_id);
        if (empty($pertanyaan)) {
            exit("Pertanyaan tidak ditemukan");
        }

        $pilihan = $this->ujian_model->retrieve_pilihan($pilihan_id, $pertanyaan['id']);
        if (empty($pilihan)) {
            exit("Pilihan tidak ditemukan");
        }

        if (empty($uri_back)) {
            $uri_back = site_url('ujian/manajemen_soal/' . $ujian['id']);
        } else {
            $uri_back = deurl_redirect($uri_back);
        }

        $this->ujian_model->create_kunci($pertanyaan['id'], $pilihan['id']);

        redirect($uri_back . '#pilihan-' . $pertanyaan['id']);
    }

    function hapus_pilihan($segment_3 = '', $segment_4 = '', $segment_5 = '', $segment_6 = '')
    {
        # harus admin atau pengajar
        if (!is_admin() AND !is_pengajar()) {
            exit("Akses ditolak.");
        }

        $ujian_id      = (int)$segment_3;
        $pertanyaan_id = (int)$segment_4;
        $pilihan_id    = (int)$segment_5;
        $uri_back      = (string)$segment_6;

        $ujian = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] != 3) {
            exit("ujian tidak ditemukan");
        }

        # jika sebagai pengajar, cek kepemilikan
        if (is_pengajar() AND $ujian['pengajar_id'] != get_sess_data('user', 'id')) {
            exit("ujian tidak ditemukan");
        }

        $pertanyaan = $this->ujian_model->retrieve_pertanyaan($pertanyaan_id);
        if (empty($pertanyaan)) {
            exit("Pertanyaan tidak ditemukan");
        }

        $pilihan = $this->ujian_model->retrieve_pilihan($pilihan_id, $pertanyaan['id']);
        if (empty($pilihan)) {
            exit("Pilihan tidak ditemukan");
        }

        if (empty($uri_back)) {
            $uri_back = site_url('ujian/manajemen_soal/' . $ujian['id']);
        } else {
            $uri_back = deurl_redirect($uri_back);
        }

        $this->ujian_model->delete_pilihan($pilihan['id']);

        redirect($uri_back . '#pilihan-' . $pertanyaan['id']);
    }

    function kerjakan($ujian_id = '')
    {
        if (!is_siswa()) {
            show_error("Anda tidak login sebagai siswa.");
        }

        $ujian_id = (int)$ujian_id;
        $ujian    = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian)) {
            show_error("ujian tidak ditemukan.");
        }

        # cek aktif tidak dan tampil siswa tidak
        if (empty($ujian['aktif'])) {
            show_error("ujian belum aktif.");
        }

        if (empty($ujian['tampil_siswa'])) {
            show_error("ujian belum aktif.");
        }

        # dibuat variabel baru untuk php versi < 5.5
        $sudah_mengerjakan = sudah_ngerjakan($ujian['id'], get_sess_data('user', 'id'));

        # cek sudah mengerjakan belum
        if ($sudah_mengerjakan == true) {
            show_error("Anda sudah mengerjakan ujian ini.");
        }

        $field_id    = 'mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
        $field_name  = 'Mengerjakan ujian';

        $mulai   = date('Y-m-d H:i:s');
        $durasi  = $ujian['durasi'];
        $selesai = date('Y-m-d H:i:s', strtotime("+$durasi minutes", strtotime($mulai)));

        $field_value = array(
            'mulai'      => $mulai,
            'selesai'    => $selesai,
            'uri_string' => uri_string()
        );

        # untuk keperluan check sedang ujian
        $field_value['valid_route'] = array(
            '/ujian/kerjakan',
            '/ujian/finish',
            '/ujian/submit_essay',
            '/ujian/submit_upload',
        );

        # simpan ujian dan unix_id nya
        $field_value['ujian']        = $ujian;
        $field_value['unix_id']      = md5($field_id) . rand(9, 999999);
        $field_value['ip']           = get_ip();
        $field_value['agent_string'] = $this->agent->agent_string();

        # cek sudah pernah mengerjakan belum, untuk keamanan.
        # karna bisa saja dibuka 2 kali dikomputer yang berbeda
        $check_field = retrieve_field($field_id);
        if (!empty($check_field)) {
            $check_field_value = json_decode($check_field['value'], 1);

            # cek upload tidak dan sudah selesai belum dari segi waktunya
            if ($ujian['type_id'] != 1 AND strtotime($mulai) >= strtotime($check_field_value['selesai'])) {
                redirect('ujian/finish/' . $ujian['id'] . '/' . $check_field_value['unix_id']);
            }
        }

        # jika masih kosong, berarti belum mengerjakan sama sekali
        else {
            $pertanyaan = array();
            if ($ujian['type_id'] != 1) {
                # ambil pertanyaan diujian ini
                $pertanyaan    = $this->ujian_model->retrieve_all_pertanyaan('all', 1, $ujian['id'], 'random');
                $pertanyaan_id = array();
                foreach ($pertanyaan as $key => $val) {
                    $pertanyaan_id[$key] = $val['id'];
                }

                # jika pertanyaan masih kosong
                if (empty($pertanyaan_id)) {
                    show_error("Pertanyaan ujian masih kosong.");
                }

                $field_value['pertanyaan_id'] = $pertanyaan_id;
            } else {
                unset($field_value['selesai']);
            }

            # start transaksi
            $this->db->trans_start();
            # simpan
            create_field($field_id, $field_name, json_encode($field_value));

            $this->db->trans_complete();
            if ($this->db->trans_status() === FALSE) {
                show_error("Proses simpan field gagal.");
            }
        }

        $check_field       = retrieve_field($field_id);
        $check_field_value = json_decode($check_field['value'], 1);

        # kondisi untuk versi ujian yang terlanjur dibuat di versi < 1.5
        if (!isset($check_field_value['pertanyaan_id']) AND isset($check_field_value['pertanyaan'])) {
            $check_field_value['pertanyaan_id'] = array();
            foreach ($check_field_value['pertanyaan'] as $key => $p) {
                $check_field_value[$key] = $p['id'];
            }

            # update
            unset($check_field_value['pertanyaan']);

            # start transaksi
            $this->db->trans_start();
            update_field($field_id, $check_field['nama'], json_encode($check_field_value));

            $this->db->trans_complete();
            if ($this->db->trans_status() === FALSE) {
                show_error("Proses update field gagal.");
            }
        }

        # ini untuk mendapatkan data soal lengkapnya
        if (!empty($check_field_value['pertanyaan_id'])) {
            $soal = array();
            foreach ($check_field_value['pertanyaan_id'] as $key => $p_id) {
                $pertanyaan = $this->ujian_model->retrieve_pertanyaan($p_id);

                # jika pilihan ganda ambil pilihannya
                if ($check_field_value['ujian']['type_id'] == 3) {
                    $pertanyaan['pilihan'] = $this->ujian_model->retrieve_all_pilihan($pertanyaan['id']);
                }

                $soal[$key] = $pertanyaan;
            }
            $check_field_value['pertanyaan'] = $soal;
        }

        if ($ujian['type_id'] != 1) {
            # cari sisa waktu dalam menit
            $sisa_menit = (strtotime($check_field_value['selesai']) - strtotime($mulai));
            $check_field_value['sisa_menit'] = ceil($sisa_menit);
        }

        # save data
        $data['data'] = $check_field_value;
        $html_js      = '';
        $html_css     = '';

        if ($ujian['type_id'] != 1) {
            $html_js = load_comp_js(array(
                base_url('assets/comp/jcounter/js/jquery.jCounter-0.1.4.js'),
                base_url('assets/comp/jquery/ujian-ujian.js'),
            ));

            $html_css .= load_comp_css(array(
                base_url('assets/comp/jcounter/css/jquery.jCounter-iosl.css'),
            ));
        }

        if ($ujian['type_id'] == 2) {
            $html_js .= get_texteditor();
            $data['data']['str_id'] = implode(',', $check_field_value['pertanyaan_id']);
        }

        $data['comp_js']  = $html_js;
        $data['comp_css'] = $html_css;
        $this->twig->display('ujian-online-ujian.html', $data);
    }

    function finish($ujian_id = '', $unix_id = '')
    {
        if (!is_siswa()) {
            show_error("Anda tidak login sebagai siswa.");
        }

        $ujian_id = (int)$ujian_id;
        $ujian    = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] == 1) {
            show_error("ujian tidak ditemukan.");
        }

        if (empty($unix_id)) {
            show_error("Parameter Unix ID dibutuhkan.");
        }

        # dibuat variabel baru untuk php versi < 5.5
        $sudah_mengerjakan = sudah_ngerjakan($ujian['id'], get_sess_data('user', 'id'));

        # cek sudah mengerjakan belum
        if ($sudah_mengerjakan == true) {
            show_error("Anda sudah mengerjakan ujian ini.");
        }

        $field_id    = 'mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
        $check_field = retrieve_field($field_id);

        if (!empty($check_field)) {
            # bandingkan unix_id nya
            $check_field_value = json_decode($check_field['value'], 1);
            if ($unix_id != $check_field_value['unix_id']) {
                show_error("Anda tidak mengerjakan ujian ini.");
            }

            # jika pilihan ganda langsung di hitung benar salahnya
            if ($ujian['type_id'] == 3) {
                # kondisi untuk versi ujian yang terlanjur dibuat di versi < 1.5
                if (!isset($check_field_value['pertanyaan_id']) AND isset($check_field_value['pertanyaan'])) {
                    $check_field_value['pertanyaan_id'] = array();
                    foreach ($check_field_value['pertanyaan'] as $key => $p) {
                        $check_field_value[$key] = $p['id'];
                    }

                    unset($check_field_value['pertanyaan']);
                }

                $jml_soal = count($check_field_value['pertanyaan_id']);

                # cari kunci jawaban
                $data_kunci = array();
                foreach ($check_field_value['pertanyaan_id'] as $p_id) {
                    foreach ($this->ujian_model->retrieve_all_pilihan($p_id) as $pilihan) {
                        if ($pilihan['kunci'] == 1) {
                            $data_kunci[$p_id] = $pilihan['id'];
                        }
                    }
                }

                $jml_benar = 0;
                $jml_salah = 0;

                # cari jawabannya
                if (!empty($check_field_value['jawaban'])) {
                    foreach ($check_field_value['jawaban'] as $pertanyaan_id => $pilihan_id) {
                        # cek jawaban benar tidak
                        if (isset($data_kunci[$pertanyaan_id]) && $data_kunci[$pertanyaan_id] == $pilihan_id) {
                            $jml_benar++;
                        } else {
                            $jml_salah++;
                        }
                    }

                    $nilai = ($jml_benar / $jml_soal) * 100;
                } else {
                    $jml_benar = 0;
                    $jml_salah = 0;
                    $nilai     = 0;
                }

                # start transaksi
                $this->db->trans_start();

                # simpan nilai
                $this->ujian_model->create_nilai($nilai, $ujian['id'], get_sess_data('user', 'id'));

                # hapus field tambahan
                delete_field($field_id);

                # simpan history
                $new_field_id                     = 'history-mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
                $check_field_value['nilai']       = $nilai;
                $check_field_value['jml_benar']   = $jml_benar;
                $check_field_value['jml_salah']   = $jml_salah;

                $sekarang                          = date('Y-m-d H:i:s');
                $check_field_value['tgl_submit']   = $sekarang;
                $check_field_value['total_waktu']  = lama_pengerjaan($check_field_value['mulai'], $sekarang);
                $check_field_value['ip']           = get_ip();
                $check_field_value['agent_string'] = $this->agent->agent_string();

                create_field($new_field_id, 'History pengerjaan ujian', json_encode($check_field_value));

                $this->db->trans_complete();

                if ($this->db->trans_status() === FALSE) {
                    show_error("Proses simpan jawaban gagal, mohon coba submit kembali.");
                }
            }

            # jika essay dan upload, biar dikoreksi dl
            else {
                # start transaksi
                $this->db->trans_start();

                # hapus field tambahan
                delete_field($field_id);

                # simpan history
                $new_field_id                      = 'history-mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
                $sekarang                          = date('Y-m-d H:i:s');
                $check_field_value['tgl_submit']   = $sekarang;
                $check_field_value['total_waktu']  = lama_pengerjaan($check_field_value['mulai'], $sekarang);
                $check_field_value['ip']           = get_ip();
                $check_field_value['agent_string'] = $this->agent->agent_string();

                create_field($new_field_id, 'History pengerjaan ujian', json_encode($check_field_value));

                $this->db->trans_complete();

                if ($this->db->trans_status() === FALSE) {
                    show_error("Proses simpan jawaban gagal, mohon coba submit kembali.");
                }
            }

            $this->session->set_flashdata('ujian', get_alert('success', 'Anda telah berhasil mengerjakan ujian ini.'));

            $this->twig->display('redirect.html', array('redirect_to' => site_url('ujian')));
        }
        # ini belum mengerjakan
        else {
            show_error("Anda belum mengerjakan ujian ini.");
        }
    }

    function submit_essay($ujian_id = '', $unix_id = '')
    {
        if (!is_siswa()) {
            show_error("Anda tidak login sebagai siswa.");
        }

        $ujian_id = (int)$ujian_id;
        $ujian    = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] != 2) {
            show_error("ujian tidak ditemukan.");
        }

        if (empty($unix_id)) {
            show_error("Parameter Unix ID dibutuhkan.");
        }

        # dibuat variabel baru untuk php versi < 5.5
        $sudah_mengerjakan = sudah_ngerjakan($ujian['id'], get_sess_data('user', 'id'));

        # cek sudah mengerjakan belum
        if ($sudah_mengerjakan == true) {
            show_error("Anda sudah mengerjakan ujian ini.");
        }

        $field_id    = 'mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
        $check_field = retrieve_field($field_id);

        if (!empty($check_field)) {
            # bandingkan unix_id nya
            $check_field_value = json_decode($check_field['value'], 1);
            if ($unix_id != $check_field_value['unix_id']) {
                $this->session->set_flashdata('ujian', get_alert('warning', 'Anda tidak mengerjakan ujian ini.'));
                redirect('ujian');
            }

            # kondisi untuk versi ujian yang terlanjur dibuat di versi < 1.5
            if (!isset($check_field_value['pertanyaan_id']) AND isset($check_field_value['pertanyaan'])) {
                $check_field_value['pertanyaan_id'] = array();
                foreach ($check_field_value['pertanyaan'] as $key => $p) {
                    $check_field_value[$key] = $p['id'];
                }

                unset($check_field_value['pertanyaan']);
            }

            $post_jawaban = $this->input->post('jawaban');
            foreach ($post_jawaban as $pertanyaan_id => $jawaban) {
                # replace yang sudah terimpan atau yang belum disimpan
                $check_field_value['jawaban'][$pertanyaan_id] = $jawaban;
            }

            # start transaksi
            $this->db->trans_start();

            # hapus field tambahan
            delete_field($field_id);

            # simpan history
            $new_field_id                      = 'history-mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
            $sekarang                          = date('Y-m-d H:i:s');
            $check_field_value['tgl_submit']   = $sekarang;
            $check_field_value['total_waktu']  = lama_pengerjaan($check_field_value['mulai'], $sekarang);
            $check_field_value['ip']           = get_ip();
            $check_field_value['agent_string'] = $this->agent->agent_string();

            create_field($new_field_id, 'History pengerjaan ujian', json_encode($check_field_value));

            $this->db->trans_complete();

            if ($this->db->trans_status() === FALSE) {
                show_error("Proses simpan jawaban gagal, mohon coba submit kembali.");
            }

            $this->session->set_flashdata('ujian', get_alert('success', 'Anda telah berhasil mengerjakan ujian ini.'));

            $this->twig->display('redirect.html', array('redirect_to' => site_url('ujian')));
        }
        # ini belum mengerjakan
        else {
            show_error("Anda belum mengerjakan ujian ini.");
        }
    }

    function submit_upload($ujian_id = '', $unix_id = '')
    {
        if (!is_siswa()) {
            show_error("Anda tidak login sebagai siswa.");
        }

        $ujian_id = (int)$ujian_id;
        $ujian    = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian) OR $ujian['type_id'] != 1) {
            show_error("ujian tidak ditemukan.");
        }

        if (empty($unix_id)) {
            show_error("Parameter Unix ID dibutuhkan.");
        }

        # dibuat variabel baru untuk php versi < 5.5
        $sudah_mengerjakan = sudah_ngerjakan($ujian['id'], get_sess_data('user', 'id'));

        # cek sudah mengerjakan belum
        if ($sudah_mengerjakan == true) {
            show_error("Anda sudah mengerjakan ujian ini.");
        }

        $field_id    = 'mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
        $check_field = retrieve_field($field_id);

        if (!empty($check_field)) {
            # bandingkan unix_id nya
            $check_field_value = json_decode($check_field['value'], 1);
            if ($unix_id != $check_field_value['unix_id']) {
                show_error("Anda tidak mengerjakan ujian ini.");
            }

            $config['upload_path']   = get_path_file();
            $config['allowed_types'] = 'doc|zip|rar|txt|docx|xls|xlsx|pdf|tar|gz|jpg|jpeg|JPG|JPEG|png|ppt|pptx';
            $config['max_size']      = '0';
            $config['max_width']     = '0';
            $config['max_height']    = '0';
            $config['file_name']     = $unix_id;
            $this->upload->initialize($config);

            if ($this->upload->do_upload()) {
                $upload_data = $this->upload->data();
                $check_field_value['file_name'] = $upload_data['file_name'];
            } else {
                $this->session->set_flashdata('upload', '<span class="text-error">' . $this->upload->display_errors() . '</span>');
                redirect('ujian/kerjakan/' . $ujian['id']);
            }

            # start transaksi
            $this->db->trans_start();

            # hapus field tambahan
            delete_field($field_id);

            # simpan history
            $new_field_id                      = 'history-mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
            $sekarang                          = date('Y-m-d H:i:s');
            $check_field_value['tgl_submit']   = $sekarang;
            $check_field_value['ip']           = get_ip();
            $check_field_value['agent_string'] = $this->agent->agent_string();

            create_field($new_field_id, 'History pengerjaan ujian', json_encode($check_field_value));

            $this->db->trans_complete();

            if ($this->db->trans_status() === FALSE) {
                show_error("Proses simpan jawaban gagal, mohon coba submit kembali.");
            }

            $this->session->set_flashdata('ujian', get_alert('success', 'Anda telah berhasil mengerjakan ujian ini.'));

            $this->twig->display('redirect.html', array('redirect_to' => site_url('ujian')));
        }
        # ini belum mengerjakan
        else {
            show_error("Anda belum mengerjakan ujian ini.");
        }
    }

    function nilai($ujian_id = '', $mode = '')
    {
        $ujian_id = (int)$ujian_id;
        $ujian    = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian)) {
            redirect('ujian');
        }

        $data['ujian'] = $this->formatData($ujian);

        # jika pengajar atau admin
        if (is_pengajar() OR is_admin()) {
            # ini harus ganda
            if ($ujian['type_id'] != 3) {
                redirect('ujian');
            }

            # kelas
            $kelas_nilai = array();

            # ambil nilai
            $data_nilai     = array();
            $retrieve_nilai = $this->ujian_model->retrieve_all_nilai($ujian['id']);
            foreach ($retrieve_nilai as $nilai) {
                # cari history
                $history_id = 'history-mengerjakan-' . $nilai['siswa_id'] . '-' . $ujian['id'];
                $history    = retrieve_field($history_id);

                # jika history kosong, hapus nilai
                if (empty($history)) {
                    $this->ujian_model->delete_nilai($nilai['id']);
                    continue;
                }

                $nilai['history'] = $history;
                $nilai['history']['value'] = json_decode($history['value'], 1);

                # cari siswa
                $siswa = $this->siswa_model->retrieve($nilai['siswa_id']);

                # kelas siswa
                $kelas_siswa = $this->kelas_model->retrieve_siswa(null, array(
                    'siswa_id' => $nilai['siswa_id'],
                    'aktif'    => 1
                ));
                $kelas = $this->kelas_model->retrieve($kelas_siswa['kelas_id']);
                $siswa['kelas_aktif'] = $kelas;

                if (!isset($kelas_nilai[$kelas['id']])) {
                    $kelas_nilai[$kelas['id']] = $kelas;
                }

                $nilai['siswa'] = $siswa;

                # kalo ada filter tampil jawaban
                if (!empty($_POST['tampil_jawaban'])) {
                    # cari kunci
                    $list_kunci = array();
                    foreach ($nilai['history']['value']['pertanyaan_id'] as $h_pertanyaan_id) {
                        $row_kunci   = array();
                        $semua_kunci = $this->ujian_model->retrieve_all_pilihan($h_pertanyaan_id);
                        foreach ($semua_kunci as $h_pilihan) {
                            if ($h_pilihan['kunci'] == 1) {
                                $row_kunci = $h_pilihan;
                            }
                        }

                        $list_kunci[$h_pertanyaan_id] = $row_kunci;
                    }

                    $array_format_jawaban = array();

                    $no_tampil = 1;
                    foreach ($list_kunci as $h_pertanyaan_id => $h_pilihan) {
                        $label_key = "";
                        if (!empty($h_pilihan['urutan'])) {
                            $label_key = get_abjad($h_pilihan['urutan']);
                        }

                        $label_jawaban = "";
                        if (isset($nilai['history']['value']['jawaban'][$h_pertanyaan_id])) {
                            $pilihan_jawaban = $this->ujian_model->retrieve_pilihan($nilai['history']['value']['jawaban'][$h_pertanyaan_id], $h_pertanyaan_id);
                            $label_jawaban   = get_abjad($pilihan_jawaban['urutan']);
                        }

                        $array_format_jawaban[] = "{$no_tampil}. {$label_key}:{$label_jawaban}";
                        $no_tampil++;
                    }

                    $nilai['tampil_jawaban'] = implode(", ", $array_format_jawaban);
                }

                # kalo ada filter kelas
                if (!empty($_POST['kelas_id'])) {
                    if ($_POST['kelas_id'] == 'all' OR $kelas['id'] == $_POST['kelas_id']) {
                        $data_nilai[] = $nilai;
                    }
                } else {
                    $data_nilai[] = $nilai;
                }
            }

            if (!empty($_POST['tampil_jawaban'])) {
                $data['tampil_jawaban'] = 1;
            }

            $data['data_nilai']  = $data_nilai;
            $data['kelas_nilai'] = $kelas_nilai;

            if ($mode == 'print') {
                $this->twig->display('print-nilai-ujian.html', $data);
            } elseif ($mode == 'export_excel') {
                header("Content-type: application/vnd-ms-excel");
                header("Content-Disposition: attachment; filename=nilai-" . url_title($data['ujian']['judul'], '-', true)  . ".xls");
                $this->twig->display('export-excel-nilai-ujian.html', $data);
            } else {
                # panggil datatables dan combobox
                $data['comp_js'] = load_comp_js(array(
                    base_url('assets/comp/datatables/jquery.dataTables.js'),
                    base_url('assets/comp/datatables/datatable-bootstrap2.js'),
                    base_url('assets/comp/colorbox/jquery.colorbox-min.js'),
                ));

                $data['comp_css'] = load_comp_css(array(
                    base_url('assets/comp/datatables/datatable-bootstrap2.css'),
                    base_url('assets/comp/colorbox/colorbox.css'),
                ));

                $this->twig->display('list-nilai-ujian.html', $data);
            }
        }

        if (is_siswa()) {
            $nilai         = $this->ujian_model->retrieve_nilai(null, $ujian['id'], get_sess_data('user', 'id'));
            $data['nilai'] = $nilai;

            # cari history
            $history_id = 'history-mengerjakan-' . get_sess_data('user', 'id') . '-' . $ujian['id'];
            $history    = retrieve_field($history_id);

            if (empty($history)) {
                exit('ujian belum dikerjakan');
            }

            $history_value   = json_decode($history['value'], 1);
            $data['history'] = $history_value;

            $this->twig->display('lihat-nilai-ujian.html', $data);
        }
    }

    function koreksi($ujian_id = '', $mode = '')
    {
        if (is_siswa()) {
            redirect('ujian');
        }

        $ujian_id = (int)$ujian_id;
        $ujian    = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian)) {
            redirect('ujian');
        }

        # ini essay atau upload
        if ($ujian['type_id'] == 3) {
            redirect('ujian');
        }

        $data['ujian'] = $this->formatData($ujian);

        $data_siswa = array();

        # kelas
        $kelas_nilai = array();

        # ambil history
        $retrieve_all_history = $this->ujian_model->retrieve_all_history($ujian_id);
        foreach ($retrieve_all_history as $history) {
            # cari siswa_id
            $split_id = explode('-' , $history['id']);
            $siswa_id = $split_id[2];

            # cari ujian_id
            $history_ujian_id = end($split_id);
            if ($history_ujian_id != $ujian['id']) {
                continue;
            }

            # kondisi untuk versi ujian yang terlanjur dibuat di versi < 1.5
            if (!isset($history['pertanyaan_id']) AND isset($history['pertanyaan'])) {
                $history['pertanyaan_id'] = array();
                foreach ($history['pertanyaan'] as $key => $p) {
                    $history[$key] = $p['id'];
                }

                unset($history['pertanyaan']);
            }

            # cari siswa
            $siswa = $this->siswa_model->retrieve($siswa_id);
            if (empty($siswa)) continue;

            # kelas siswa
            $kelas_siswa = $this->kelas_model->retrieve_siswa(null, array(
                'siswa_id' => $siswa_id,
                'aktif'    => 1
            ));
            $kelas = $this->kelas_model->retrieve($kelas_siswa['kelas_id']);
            $siswa['kelas_aktif'] = $kelas;
            $siswa['history']     = $history;
            $siswa['history']['value'] = json_decode($history['value'], 1);

            if (!isset($kelas_nilai[$kelas['id']])) {
                $kelas_nilai[$kelas['id']] = $kelas;
            }

            # cari nilai
            $siswa['nilai'] = $this->ujian_model->retrieve_nilai(null, $ujian['id'], $siswa['id']);

            if (!empty($_POST['kelas_id'])) {
                if ($_POST['kelas_id'] == 'all' OR $kelas['id'] == $_POST['kelas_id']) {
                    $data_siswa[] = $siswa;
                }
            } else {
                $data_siswa[] = $siswa;
            }
        }
        $data['data_siswa']  = $data_siswa;
        $data['kelas_nilai'] = $kelas_nilai;

        if ($mode == 'print') {
            $this->twig->display('print-nilai-ujian.html', $data);
        } elseif ($mode == 'export_excel') {
            header("Content-type: application/vnd-ms-excel");
            header("Content-Disposition: attachment; filename=nilai-" . url_title($data['ujian']['judul'], '-', true)  . ".xls");
            $this->twig->display('export-excel-nilai-ujian.html', $data);
        } else {
            # panggil datatables dan combobox
            $data['comp_js'] = load_comp_js(array(
                base_url('assets/comp/datatables/jquery.dataTables.js'),
                base_url('assets/comp/datatables/datatable-bootstrap2.js'),
                base_url('assets/comp/colorbox/jquery.colorbox-min.js')
            ));

            $data['comp_css'] = load_comp_css(array(
                base_url('assets/comp/datatables/datatable-bootstrap2.css'),
                base_url('assets/comp/colorbox/colorbox.css'),
            ));

            $this->twig->display('list-peserta-ujian.html', $data);
        }
    }

    function detail_jawaban($siswa_id = '', $ujian_id = '')
    {
        $siswa_id = (int)$siswa_id;
        $siswa    = $this->siswa_model->retrieve($siswa_id);
        if (empty($siswa)) {
            exit('Siswa tidak ditemukan');
        }

        # cek jika siswa, punya dia tidak
        if (is_siswa() AND $siswa['id'] != get_sess_data('user', 'id')) {
            exit('Akses ditolak');
        }

        # kelas siswa
        $kelas_siswa = $this->kelas_model->retrieve_siswa(null, array(
            'siswa_id' => $siswa_id,
            'aktif'    => 1
        ));
        $kelas = $this->kelas_model->retrieve($kelas_siswa['kelas_id']);
        $siswa['kelas_aktif'] = $kelas;

        $ujian_id = (int)$ujian_id;
        $ujian    = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian)) {
            exit('ujian tidak ditemukan');
        }

        $data['ujian'] = $this->formatData($ujian);
        $data['siswa'] = $siswa;

        # cari history
        $history_id = 'history-mengerjakan-' . $siswa['id'] . '-' . $ujian['id'];
        $history    = retrieve_field($history_id);

        if (empty($history)) {
            exit('ujian belum dikerjakan');
        }

        $history_value = json_decode($history['value'], 1);

        # ini utnuk mengantisipasi versi < 1.5
        if (!empty($history_value['pertanyaan_id'])) {
            $soal = array();
            foreach ($history_value['pertanyaan_id'] as $key => $p_id) {
                $pertanyaan = $this->ujian_model->retrieve_pertanyaan($p_id);

                # jika pilihan ganda ambil pilihannya
                if ($history_value['ujian']['type_id'] == 3) {
                    $pertanyaan['pilihan'] = $this->ujian_model->retrieve_all_pilihan($pertanyaan['id']);
                }

                $soal[$key] = $pertanyaan;
            }
            $history_value['pertanyaan'] = $soal;
        }

        $data['history'] = $history_value;

        if (!empty($_GET['mode'])) {
            $data['mode'] = $_GET['mode'];
        }

        if ($ujian['type_id'] == 3) {
            $this->twig->display('detail-jawaban-ganda-ujian.html', $data);
        } elseif ($ujian['type_id'] == 2) {
            # jika ada post nilai
            if (!empty($_POST['nilai'])) {
                $total_nilai = 0;
                foreach ($_POST['nilai'] as $p_id => $p_nilai) {
                    $total_nilai = $total_nilai + $p_nilai;
                }

                # update history
                $new_history          = $history_value;
                $new_history['nilai'] = $_POST['nilai'];
                unset($new_history['pertanyaan']);

                # start transaksi
                $this->db->trans_start();

                update_field($history_id, $history['nama'], json_encode($new_history));

                # simpan atau update nilai
                $check = $this->ujian_model->retrieve_nilai(null, $ujian['id'], $siswa['id']);
                if (empty($check)) {
                    $this->ujian_model->create_nilai($total_nilai, $ujian['id'], $siswa['id']);
                } else {
                    $this->ujian_model->update_nilai($check['id'], $total_nilai, $ujian['id'], $siswa['id']);
                }

                $this->db->trans_complete();

                if ($this->db->trans_status() === FALSE) {
                    show_error("Proses simpan/update nilai gagal, mohon coba kembali.");
                }

                redirect('ujian/detail_jawaban/' . $siswa['id'] . '/' . $ujian['id']);
            }

            # cek sudah koreksi belum, dengan cara cek nilainya sudah ada belum
            $nilai                   = $this->ujian_model->retrieve_nilai(null, $ujian['id'], $siswa['id']);
            $data['sudah_dikoreksi'] = !empty($nilai) ? true : false;
            $data['nilai']           = $nilai;

            $this->twig->display('detail-jawaban-essay-ujian.html', $data);
        } elseif ($ujian['type_id'] == 1) {
            if (!empty($_POST['nilai'])) {
                $nilai = $this->input->post('nilai', true);

                # update history
                $new_history          = $history_value;
                $new_history['nilai'] = $nilai;
                unset($new_history['pertanyaan']);

                # start transaksi
                $this->db->trans_start();

                update_field($history_id, $history['nama'], json_encode($new_history));

                # simpan atau update nilai
                $check = $this->ujian_model->retrieve_nilai(null, $ujian['id'], $siswa['id']);
                if (empty($check)) {
                    $this->ujian_model->create_nilai($nilai, $ujian['id'], $siswa['id']);
                } else {
                    $this->ujian_model->update_nilai($check['id'], $nilai, $ujian['id'], $siswa['id']);
                }

                $this->db->trans_complete();

                if ($this->db->trans_status() === FALSE) {
                    show_error("Proses simpan/update nilai gagal, mohon coba kembali.");
                }

                redirect('ujian/detail_jawaban/' . $siswa['id'] . '/' . $ujian['id']);
            }

            # cek sudah koreksi belum, dengan cara cek nilainya sudah ada belum
            $nilai                   = $this->ujian_model->retrieve_nilai(null, $ujian['id'], $siswa['id']);
            $data['sudah_dikoreksi'] = !empty($nilai) ? true : false;
            $data['nilai']           = $nilai;

            $data['file_info']         = get_file_info(get_path_file($history_value['file_name']));
            # bug ci http://stackoverflow.com/questions/24095996/codeignter-get-file-info-returns-filename-as-false
            if (empty($data['file_info']['name'])) {
                $data['file_info']['name'] = $history_value['file_name'];
            }
            $data['file_info']['mime'] = get_mime_by_extension(get_path_file($history_value['file_name']));

            $this->twig->display('detail-jawaban-upload-ujian.html', $data);
        }
    }

    function reset_jawaban($ujian_id, $siswa_id)
    {
        # jika pengajar atau admin
        if (is_pengajar() OR is_admin()) {
            $ujian_id = (int)$ujian_id;
            $ujian    = $this->ujian_model->retrieve($ujian_id);
            if (empty($ujian)) {
                show_error("ujian tidak ditemukan.");
            }

            $siswa = $this->siswa_model->retrieve($siswa_id);
            if (empty($siswa)) {
                show_error("Siswa tidak ditemukan.");
            }

            $result_reset = $this->reset_nilai_jawaban_ujian($siswa['id'], $ujian['id'], $ujian);
            if (!$result_reset) {
                show_error("Proses reset jawaban gagal, mohon coba kembali.");
            }

            $this->session->set_flashdata('ujian', get_alert('success', 'Siswa berhasil dianggap belum mengerjakan.'));
            if ($ujian['type_id'] == 3) {
                redirect('ujian/nilai/' . $ujian['id']);
            } else {
                redirect('ujian/koreksi/' . $ujian['id']);
            }
        }
        else {
            show_error("Akses ditolak.");
        }
    }

    function bulk_reset_jawaban($ujian_id)
    {
        # jika pengajar atau admin
        if (is_pengajar() OR is_admin()) {
            $ujian_id = (int)$ujian_id;
            $ujian    = $this->ujian_model->retrieve($ujian_id);
            if (empty($ujian)) {
                show_error("ujian tidak ditemukan.");
            }

            $reset_tipe = $this->input->post("reset_tipe", true);
            $siswa_ids  = $this->input->post("siswa_id", true);
            $url_back   = $this->input->post("url_back", true);

            if ($reset_tipe == "terpilih") {
                if (empty($siswa_ids)) {
                    $this->session->set_flashdata('ujian', get_alert('warning', 'Pilih siswa yang ingin direset.'));
                    redirect($url_back);
                }

                foreach ($siswa_ids as $siswa_id) {
                    $siswa = $this->siswa_model->retrieve($siswa_id);
                    if (empty($siswa)) {
                        continue;
                    }

                    $this->reset_nilai_jawaban_ujian($siswa['id'], $ujian['id'], $ujian);
                }

                $this->session->set_flashdata('ujian', get_alert('success', 'Siswa berhasil dianggap belum mengerjakan.'));
                redirect($url_back);
            }
            elseif ($reset_tipe == "semua") {
                # ambil semua history
                $retrieve_all_history = $this->ujian_model->retrieve_all_history($ujian['id']);
                foreach ($retrieve_all_history as $history) {
                    $split_id = explode("-", $history['id']);
                    $siswa_id = $split_id[2];

                    $this->reset_nilai_jawaban_ujian($siswa_id, $ujian['id'], $ujian);
                }

                if (!empty($retrieve_all_history)) {
                    $this->session->set_flashdata('ujian', get_alert('success', 'Semua siswa berhasil dianggap belum mengerjakan.'));
                }

                redirect($url_back);
            }
            else {
                show_error("Tipe reset tidak ditemukan.");
            }
        }
        else {
            show_error("Akses ditolak.");
        }
    }

    function pantau($ujian_id = '', $aksi = 'list', $param1 = '')
    {
        $ujian_id = (int)$ujian_id;
        $ujian    = $this->ujian_model->retrieve($ujian_id);
        if (empty($ujian)) {
            redirect('ujian');
        }

        # jika ujian bertipe upload tidak dapat dipantau
        if ($ujian['type_id'] == 1) {
            show_error("Maaf tipe ujian tidak dapat dipantau.");
        }

        $data['ujian'] = $this->formatData($ujian);

        # jika pengajar atau admin
        if (is_pengajar() OR is_admin()) {

            switch ($aksi) {
                case 'reset':
                    $siswa_id = (int)$param1;

                    $field_id = 'mengerjakan-' . $siswa_id . '-' . $ujian['id'];
                    delete_field($field_id);

                    $this->session->set_flashdata('ujian', get_alert('success', 'Proses ujian siswa berhasil diulang.'));
                    redirect('ujian/pantau/' . $ujian['id']);
                break;

                case 'jawaban_sementara':
                    $siswa_id = (int)$param1;

                    $field_id = 'mengerjakan-' . $siswa_id . '-' . $ujian['id'];
                    $mengerjakan = retrieve_field($field_id);
                    if (empty($mengerjakan)) {
                        show_error("Data tidak ditemukan.");
                    }

                    $de_val = json_decode($mengerjakan['value'], 1);
                    if (empty($de_val['pertanyaan_id'])) {
                        show_error("Maaf jawaban tidak dapat ditampilkan, karena dikerjakan pada e-learning dibawah versi 1.6.");
                    }

                    $soal  = array();
                    $benar = 0;
                    $salah = 0;
                    $essay_kosong   = 0;
                    $essay_terjawab = 0;
                    foreach ($de_val['pertanyaan_id'] as $key => $p_id) {
                        $pertanyaan = $this->ujian_model->retrieve_pertanyaan($p_id);

                        # jika pilihan ganda ambil pilihannya
                        if ($de_val['ujian']['type_id'] == 3) {
                            $pertanyaan['pilihan'] = $this->ujian_model->retrieve_all_pilihan($pertanyaan['id']);

                            if (!empty($de_val['jawaban']) AND get_jawaban($de_val['jawaban'], $p_id) == get_kunci_pilihan($pertanyaan['pilihan'])) {
                                $benar++;
                            } elseif (!empty($de_val['jawaban'][$p_id])) {
                                $salah++;
                            }
                        }
                        # essay
                        elseif ($de_val['ujian']['type_id'] == 2) {
                            if (!isset($de_val['jawaban'][$p_id])) {
                                $essay_kosong++;
                            } else {
                                $jawaban_p_id = trim($de_val['jawaban'][$p_id]);
                                if (empty($jawaban_p_id)) {
                                    $essay_kosong++;
                                } else {
                                    $essay_terjawab++;
                                }
                            }
                        }

                        $soal[$key] = $pertanyaan;
                    }

                    if ($de_val['ujian']['type_id'] == 2) {
                        $de_val['jml_kosong']   = $essay_kosong;
                        $de_val['jml_terjawab'] = $essay_terjawab;
                    }

                    $de_val['jml_benar']  = $benar;
                    $de_val['jml_salah']  = $salah;
                    $de_val['pertanyaan'] = $soal;
                    $data = array_merge($data, $de_val);

                    $this->twig->display('pantau-jawaban-sementara-ujian.html', $data);
                break;

                case 'list':
                default:
                    # cari semua yang sedang ujian pada ujian ini
                    $retrieve_all = $this->ujian_model->retrieve_all_mengerjakan($ujian_id);
                    foreach ($retrieve_all as $key => $mengerjakan) {
                        $split_id = explode("-", $mengerjakan['id']);
                        $siswa_id = $split_id[1];

                        # cari siswa
                        $siswa = $this->siswa_model->retrieve($siswa_id);

                        # kelas siswa
                        $kelas_siswa = $this->kelas_model->retrieve_siswa(null, array(
                            'siswa_id' => $siswa_id,
                            'aktif'    => 1
                        ));
                        $kelas = $this->kelas_model->retrieve($kelas_siswa['kelas_id']);
                        $siswa['kelas_aktif'] = $kelas;

                        $retrieve_all[$key]['value'] = json_decode($mengerjakan['value'], 1);
                        $retrieve_all[$key]['value']['siswa'] = $siswa;

                        if ($retrieve_all[$key]['value']['ujian']['type_id'] != 1) {
                            # cari sisa waktu dalam menit
                            $mulai = date('Y-m-d H:i:s');
                            $sisa_menit = (strtotime($retrieve_all[$key]['value']['selesai']) - strtotime($mulai));
                            $retrieve_all[$key]['value']['sisa_menit'] = ceil($sisa_menit);

                            if (strtotime($retrieve_all[$key]['value']['selesai']) < strtotime($mulai)) {
                                $sisa_menit_string = "<span class='text-error'><i class='icon-info-sign'></i> Harusnya sudah selesai.</span><br><span class='text-info'>Peserta terindikasi berhenti saat ujian berlangsung.</span>";
                            } else {
                                $sisa_menit_string = lama_pengerjaan($mulai, $retrieve_all[$key]['value']['selesai']);
                            }

                            $retrieve_all[$key]['value']['sisa_menit_string'] = $sisa_menit_string;
                        }

                        # biar gampang, ditaruh diluar
                        $all_value = $retrieve_all[$key]['value'];
                        unset($mengerjakan['value']);
                        $retrieve_all[$key] = array_merge($mengerjakan, $all_value);
                    }

                    $data['retrieve_all'] = $retrieve_all;

                    # panggil datatables dan combobox
                    $data['comp_js'] = load_comp_js(array(
                        base_url('assets/comp/datatables/jquery.dataTables.js'),
                        base_url('assets/comp/datatables/datatable-bootstrap2.js'),
                        base_url('assets/comp/colorbox/jquery.colorbox-min.js'),
                    ));

                    $data['comp_css'] = load_comp_css(array(
                        base_url('assets/comp/datatables/datatable-bootstrap2.css'),
                        base_url('assets/comp/colorbox/colorbox.css'),
                    ));

                    $this->twig->display('pantau-ujian-ujian.html', $data);
                break;
            }
        }
        else {
            show_error("Akses ditolak.");
        }
    }
}
